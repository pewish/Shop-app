package com.example.todo_app
class User (val login: String, val email: String, val pass: String){
}