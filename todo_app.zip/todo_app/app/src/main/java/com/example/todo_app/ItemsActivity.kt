package com.example.todo_app

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.todo_app.com.example.todo_app.Item
import com.example.todo_app.com.example.todo_app.ItemsAdapter

class ItemsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_items)

        val itemsList: RecyclerView = findViewById(R.id.itemsList)
        val items = arrayListOf<Item>()

        items.add(Item(1, "tshirt", "STARSET Футболка", "Хлопок 95% и лайкра 5%", "Even a well lit place, can hide salvation", 2000))
        items.add(Item(2, "longsleeve", "STARSET Лонгслив", "Хлопок 95% и лайкра 5%", "A map to a one man maze that never sees the sun", 3000))
        items.add(Item(3, "hoodie", "STARSET Толстовка", "Хлопок 95% и лайкра 5%", "Where the lost are the heroes and the thieves are left to drown", 4000))

        itemsList.layoutManager = LinearLayoutManager(this)
        itemsList.adapter = ItemsAdapter(items, this)
    }
}